<?php
 $hostname = "localhost";
 $hostuser = "root";
 $hostpass = "";
 $hostdb   = "fastcash";
 
 $conn = mysqli_connect($hostname, $hostuser, $hostpass, $hostdb);
 if($conn){
   
 }else{
   mysqli_error($conn);
 }

?>