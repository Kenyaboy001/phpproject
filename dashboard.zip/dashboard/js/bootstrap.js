import * as bootstrap from 'bootstrap'

try {
  window.bootstrap = bootstrap
} catch (e) {}

export { bootstrap }
